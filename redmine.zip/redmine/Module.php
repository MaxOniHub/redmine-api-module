<?php

namespace app\modules\redmine;


/**
 * redmine-api module definition class
 */
class Module extends \yii\base\Module
{
    public $controllerNamespace = "redmineModule\controllers";

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        $this->layout = 'custom';

    }
}
