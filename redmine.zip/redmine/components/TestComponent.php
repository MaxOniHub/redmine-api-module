<?php

namespace redmineModule\components;

use yii\base\Component;

class TestComponent extends Component
{
    public function welcome()
    {
        echo "Hello..Welcome to MyComponent";
    }

}